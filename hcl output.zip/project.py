# Warehouse Inventory & Stockout Risk Analysis
# Follows the SRS (FR-1 to FR-17). Runs on plain Python - NO pip install needed.
# Input : 20_warehouse_inventory.csv (same folder as this script)
# Output: report in terminal + output.txt, and sku_status_output.csv

import csv, os, sys, statistics
from collections import defaultdict

try:                      # NumPy is optional (used only for task 12 if present)
    import numpy as np
except ImportError:
    np = None

class Tee:                 # print on screen AND save to output.txt
    def __init__(self, *f): self.f = f
    def write(self, x):
        for i in self.f: i.write(x)
    def flush(self):
        for i in self.f: i.flush()
_out = open("output.txt", "w", encoding="utf-8")
sys.stdout = Tee(sys.__stdout__, _out)

CSV = "20_warehouse_inventory.csv"
FIELDS = ["SKU_ID", "Category", "Supplier", "Warehouse", "Current_Stock",
          "Reorder_Level", "Avg_Daily_Sales", "Lead_Time_Days", "Unit_Cost", "Return_Rate"]

def line(title):
    print("\n" + "=" * 60 + "\n" + title + "\n" + "=" * 60)

def num(x):                # text -> float, empty -> None
    try:
        return float(x)
    except (TypeError, ValueError):
        return None

def median(v):
    return statistics.median(v) if v else None

# ---------- check the input file ----------
if not os.path.exists(CSV):
    sys.exit(f"ERROR: '{CSV}' not found. Put it in the same folder as this script: {os.getcwd()}")

# ---------- 1. Load & inspect ----------
line("1. LOAD AND INSPECT")
with open(CSV, newline="") as f:
    data = list(csv.DictReader(f))
print("Rows:", len(data), "| Columns:", list(data[0].keys()))
for r in data[:3]:
    print(r)

# ---------- 2. Missing values & duplicates ----------
line("2. MISSING VALUES AND DUPLICATES")
for col in data[0].keys():
    miss = sum(1 for r in data if str(r[col]).strip() == "")
    if miss:
        print(f"Missing in {col}: {miss}")
seen, clean, dups = set(), [], 0
for r in data:
    if r["SKU_ID"] in seen:
        dups += 1
    else:
        seen.add(r["SKU_ID"]); clean.append(r)
print("Duplicate SKU_ID rows removed:", dups)
data = clean

# convert numbers
for r in data:
    for c in ["Current_Stock", "Reorder_Level", "Avg_Daily_Sales",
              "Lead_Time_Days", "Unit_Cost", "Return_Rate"]:
        r[c] = num(r[c])

# ---------- 3. Fill missing values (median) ----------
line("3. CLEANING (median fill)")
sup_lt, cat_cost = defaultdict(list), defaultdict(list)
for r in data:
    if r["Lead_Time_Days"] is not None: sup_lt[r["Supplier"]].append(r["Lead_Time_Days"])
    if r["Unit_Cost"] is not None:      cat_cost[r["Category"]].append(r["Unit_Cost"])
all_lt = [r["Lead_Time_Days"] for r in data if r["Lead_Time_Days"] is not None]
all_cost = [r["Unit_Cost"] for r in data if r["Unit_Cost"] is not None]
filled = 0
for r in data:
    if r["Lead_Time_Days"] is None:
        r["Lead_Time_Days"] = median(sup_lt[r["Supplier"]]) or median(all_lt); filled += 1
    if r["Unit_Cost"] is None:
        r["Unit_Cost"] = median(cat_cost[r["Category"]]) or median(all_cost); filled += 1
print("Values filled:", filled)
print("Why median? It is not affected by extreme values. Lead time uses the")
print("supplier's median, unit cost uses the category's median.")

# ---------- 4. Inventory value ----------
line("4. INVENTORY VALUE")
for r in data:
    r["Value"] = r["Current_Stock"] * r["Unit_Cost"]
total = sum(r["Value"] for r in data)
print(f"Total inventory value: {total:,.2f}")

# ---------- 5. Stockout-risk SKUs ----------
line("5. STOCKOUT-RISK SKUs (Current_Stock <= Reorder_Level)")
risk = [r for r in data if r["Current_Stock"] <= r["Reorder_Level"]]
print(f"{len(risk)} of {len(data)} SKUs are at risk. First 10:")
for r in risk[:10]:
    print(f"  {r['SKU_ID']:8} {r['Category']:12} stock={r['Current_Stock']:.0f} reorder={r['Reorder_Level']:.0f}")

# ---------- 6. Risk % by category ----------
line("6. STOCKOUT-RISK % BY CATEGORY")
cat_all, cat_risk = defaultdict(int), defaultdict(int)
for r in data:
    cat_all[r["Category"]] += 1
    if r["Current_Stock"] <= r["Reorder_Level"]:
        cat_risk[r["Category"]] += 1
for c in sorted(cat_all, key=lambda c: -cat_risk[c] / cat_all[c]):
    print(f"  {c:12} {cat_risk[c] / cat_all[c] * 100:5.1f}%")

# ---------- 7. Supplier ranking ----------
line("7. SUPPLIER RANKING (1 = best)")
g = defaultdict(list)
for r in data:
    g[r["Supplier"]].append(r)
sup = {s: (statistics.mean(x["Lead_Time_Days"] for x in v),
           statistics.mean(x["Return_Rate"] for x in v), len(v)) for s, v in g.items()}
lead_rank = {s: i for i, s in enumerate(sorted(sup, key=lambda s: sup[s][0]), 1)}
ret_rank = {s: i for i, s in enumerate(sorted(sup, key=lambda s: sup[s][1]), 1)}
order = sorted(sup, key=lambda s: lead_rank[s] + ret_rank[s])
print(f"{'Rank':5}{'Supplier':14}{'AvgLead':>9}{'AvgReturn%':>12}{'SKUs':>6}")
for i, s in enumerate(order, 1):
    print(f"{i:<5}{s:14}{sup[s][0]:9.2f}{sup[s][1]:12.2f}{sup[s][2]:6}")

# ---------- 8. Top 10 SKUs by value ----------
line("8. TOP 10 HIGHEST-VALUE SKUs")
top10 = sorted(data, key=lambda r: -r["Value"])[:10]
for r in top10:
    print(f"  {r['SKU_ID']:8} {r['Category']:12} {r['Value']:12,.0f}")
print(f"Top 10 share of total value: {sum(r['Value'] for r in top10) / total * 100:.1f}%")

# ---------- 9. Days of stock ----------
line("9. DAYS OF STOCK REMAINING")
for r in data:   # zero sales -> no division; use 9999 = 'no sales'
    r["Days"] = r["Current_Stock"] / r["Avg_Daily_Sales"] if r["Avg_Daily_Sales"] > 0 else 9999
ok = [r["Days"] for r in data if r["Days"] != 9999]
print(f"Median days of stock (SKUs with sales): {statistics.median(ok):.1f}")
print("SKUs with zero sales:", sum(1 for r in data if r["Avg_Daily_Sales"] == 0))

# ---------- 10. Overstock ----------
line("10. OVERSTOCK / SLOW MOVERS (> 90 days)")
over = [r for r in data if r["Days"] > 90]
ov = sum(r["Value"] for r in over)
print(f"{len(over)} SKUs, value {ov:,.0f} ({ov / total * 100:.1f}% of total)")

# ---------- 11. Value by warehouse ----------
line("11. VALUE BY WAREHOUSE")
wh = defaultdict(float)
for r in data:
    wh[r["Warehouse"]] += r["Value"]
for w, v in sorted(wh.items(), key=lambda x: -x[1]):
    print(f"  {w:10} {v:14,.0f}")

# ---------- 12. Lead-time statistics ----------
line("12. LEAD-TIME STATISTICS")
lt = [r["Lead_Time_Days"] for r in data]
if np is not None:
    a = np.array(lt)
    print(f"(NumPy) mean={np.mean(a):.2f} median={np.median(a):.2f} std={np.std(a, ddof=1):.2f}")
else:
    print(f"(built-in) mean={statistics.mean(lt):.2f} median={statistics.median(lt):.2f} "
          f"std={statistics.stdev(lt):.2f}   [install numpy to use NumPy here]")

# ---------- 13. IQR outliers ----------
line("13. UNUSUALLY LONG LEAD TIMES (IQR)")
q = statistics.quantiles(lt, n=4, method="inclusive")
q1, q3 = q[0], q[2]
fence = q3 + 1.5 * (q3 - q1)
long_ = [r for r in data if r["Lead_Time_Days"] > fence]
print(f"Q1={q1}, Q3={q3}, upper limit={fence:.1f} days -> {len(long_)} SKUs")
for r in long_[:10]:
    print(f"  {r['SKU_ID']:8} {r['Supplier']:14} {r['Lead_Time_Days']:.0f} days")

# ---------- 14. Stock status ----------
line("14. STOCK STATUS")
print("Rules: Critical = stock <= 50% of reorder level OR days left < half the lead time")
print("       Low = stock <= reorder level | Overstock = > 90 days | else Optimal")
count = defaultdict(int)
for r in data:
    if r["Current_Stock"] <= 0.5 * r["Reorder_Level"] or r["Days"] <= 0.5 * r["Lead_Time_Days"]:
        r["Status"] = "Critical"
    elif r["Current_Stock"] <= r["Reorder_Level"]:
        r["Status"] = "Low"
    elif r["Days"] > 90:
        r["Status"] = "Overstock"
    else:
        r["Status"] = "Optimal"
    count[r["Status"]] += 1
for s in ["Critical", "Low", "Optimal", "Overstock"]:
    print(f"  {s:10} {count[s]}")

# save a result file
with open("sku_status_output.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["SKU_ID", "Category", "Warehouse", "Value", "Days_of_Stock", "Status"])
    for r in data:
        w.writerow([r["SKU_ID"], r["Category"], r["Warehouse"], round(r["Value"], 2),
                    round(r["Days"], 1), r["Status"]])
print("\nSaved: sku_status_output.csv")

# ---------- 15. Recommendations ----------
line("15. RECOMMENDATIONS")
print("1. Reorder Critical and Low SKUs first; set automatic reorder alerts.")
print("2. Add safety stock for long-lead suppliers: reorder level = daily sales x lead time + buffer.")
print("3. Clear overstock with discounts/bundles; stop ordering zero-sales SKUs.")
print(f"4. Review the weakest supplier ({order[-1]}); move volume to {order[0]}.")
print("5. Rebalance stock between warehouses and review the top-10 value SKUs weekly.")

print("\nReport also saved in output.txt")
